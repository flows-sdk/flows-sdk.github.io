from typing import Any, Dict, List, Optional

from flows_sdk.blocks import Block, Output
from flows_sdk.utils import system_secret, workflow_input

from .idp_values import (
    IDP_OUTPUT_ROLE,
    IDP_SUBMISSION_NOTIFY_NAME,
    OCS_SECRET_KEY,
    S3_SECRET_KEY,
    Inputs,
    Settings,
)


# Submission bootstrap block initializes the submission object and prepares external images
# or other submission data if needed
class SubmissionBootstrapV2Block(Block):
    def __init__(self, reference_name: str) -> None:
        super().__init__(
            identifier='SUBMISSION_BOOTSTRAP_2',
            reference_name=reference_name,
            input={
                '$trigger': workflow_input(Inputs.Trigger),
                'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
                's3_config': system_secret(S3_SECRET_KEY),
                's3_endpoint_url': None,
                'ocs_config': system_secret(OCS_SECRET_KEY),
                'notification_workflow': IDP_SUBMISSION_NOTIFY_NAME,
                'workflow_uuid': workflow_input(Inputs.WorkflowUuid),
                'workflow_name': workflow_input(Inputs.WorkflowName),
                'workflow_version': workflow_input(Inputs.WorkflowVersion),
            },
            title='Submission Initialization',
            description='Initialize submission and, if necessary, fetch and prepare '
            'external images or other submission data',
        )


# Case collation block groups files, documents and pages (from the submission) into cases
class CaseCollationV2Block(Block):
    def __init__(self, reference_name: str, submission: Any, cases: Any) -> None:
        super().__init__(
            identifier='MACHINE_COLLATION_2',
            reference_name=reference_name,
            input={'submission': submission, 'cases': cases},
            title='Machine Collation',
            description='Group files, documents, and pages into cases',
        )


# Machine classification block automatically matches documents to structured, semi-structured
# or additional layouts
class MachineClassificationV2Block(Block):
    def __init__(
        self,
        reference_name: str,
        submission: Any,
        api_params: Any,
        rotation_correction_enabled: bool = True,
        mobile_processing_enabled: bool = False,
    ) -> None:
        super().__init__(
            identifier='MACHINE_CLASSIFICATION_2',
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
                'vpc_registration_threshold': workflow_input(
                    Settings.StructuredLayoutMatchThreshold
                ),
                'nlc_enabled': workflow_input(Settings.SemiStructuredClassification),
                'nlc_target_accuracy': workflow_input(Settings.SemiTargetAccuracy),
                'nlc_doc_grouping_logic': workflow_input(Settings.SemiDocGroupingLogic),
                'rotation_correction_enabled': rotation_correction_enabled,
                'mobile_processing_enabled': mobile_processing_enabled,
            },
            title='Machine Classification',
            description='Automatically classify documents',
        )


# Manual classification block allows keyers to manually match submissions to their layouts.
# Keyers may perform manual classification if machine classification cannot automatically
# match a submission to a layout with high confidence
class ManualClassificationV2Block(Block):
    def __init__(self, reference_name: str, submission: Any, api_params: Any) -> None:
        super().__init__(
            identifier='MANUAL_CLASSIFICATION_2',
            reference_name=reference_name,
            input={
                'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
                'manual_nlc_enabled': workflow_input(Settings.ManualNlcEnabled),
                'task_restrictions': [],
                'api_params': api_params,
                'submission': submission,
                'notification_workflow': IDP_SUBMISSION_NOTIFY_NAME,
            },
            title='Manual Classification',
            description='Manually classify documents that could not be automatically classified',
        )


# Machine identification automatically identify fields and tables in the submission
class MachineIdentificationV3Block(Block):
    def __init__(self, reference_name: str, submission: Any, api_params: Any) -> None:
        super().__init__(
            identifier='MACHINE_IDENTIFICATION_3',
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'manual_field_id_enabled': workflow_input(Settings.ManualFieldIdEnabled),
                'field_id_target_accuracy': workflow_input(Settings.FieldIdTargetAccuracy),
                'table_id_target_accuracy': workflow_input(Settings.TableIdTargetAccuracy),
            },
            title='Machine Identification',
            description='Automatically locate fields on semi-structured documents',
        )


# Manual identification allows keyers to complete field identification or table identification
# tasks, where they draw bounding boxes around the contents of certain fields, table columns
# or table rows. This identification process ensures that the system will be able to
# transcribe the correct content in the upcoming transcription process
class ManualIdentificationV3Block(Block):
    def __init__(
        self,
        reference_name: str,
        submission: Any,
        api_params: Any,
        task_restrictions: Optional[List[Any]] = None,
    ) -> None:
        if not task_restrictions:
            task_restrictions = []
        super().__init__(
            identifier='MANUAL_IDENTIFICATION_3',
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'manual_field_id_enabled': workflow_input(Settings.ManualFieldIdEnabled),
                'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
                'notification_workflow': IDP_SUBMISSION_NOTIFY_NAME,
                'task_restrictions': task_restrictions,
            },
            title='Manual Identification',
            description='Manually locate fields on semi-structured documents that '
            'could not be automatically located',
        )


# Machine transcription automatically transcribes the content of your submission
class MachineTranscriptionV3Block(Block):
    def __init__(self, reference_name: str, submission: Any, api_params: Any) -> None:
        super().__init__(
            identifier='MACHINE_TRANSCRIPTION_3',
            reference_name=reference_name,
            input={
                'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
                'submission': submission,
                'api_params': api_params,
                'transcription_automation_training': workflow_input(
                    Settings.TranscriptionAutomationTraining
                ),
                'transcription_model': workflow_input(Settings.TranscriptionModel),
                'flex_confidence_boosting_enabled': workflow_input(
                    Settings.SemiTranscriptionConfBoost
                ),
                'finetuning_only_trained_layouts': workflow_input(
                    Settings.FinetuningOnlyTrainedLayouts
                ),
                'structured_text_target_accuracy': workflow_input(
                    Settings.StructuredTextTargetAccuracy
                ),
                'structured_text_confidence_threshold': workflow_input(
                    Settings.StructuredTextThreshold
                ),
                'structured_text_acceptable_confidence': workflow_input(
                    Settings.StructuredTextMinLegThreshold
                ),
                'semi_structured_text_target_accuracy': workflow_input(
                    Settings.SemiStructuredTextTargetAccuracy
                ),
                'semi_structured_text_confidence_threshold': workflow_input(
                    Settings.SemiStructuredTextThreshold
                ),
                'semi_structured_text_acceptable_confidence': workflow_input(
                    Settings.SemiStructuredTextMinLegThreshold
                ),
                'structured_checkbox_target_accuracy': workflow_input(
                    Settings.StructuredCheckboxTargetAccuracy
                ),
                'structured_checkbox_confidence_threshold': workflow_input(
                    Settings.StructuredCheckboxThreshold
                ),
                'structured_checkbox_acceptable_confidence': workflow_input(
                    Settings.StructuredCheckboxMinLegThreshold
                ),
                'structured_signature_target_accuracy': workflow_input(
                    Settings.StructuredSignatureTargetAccuracy
                ),
                'structured_signature_confidence_threshold': workflow_input(
                    Settings.StructuredSignatureThreshold
                ),
                'structured_signature_acceptable_confidence': workflow_input(
                    Settings.StructuredSignatureMinLegThreshold
                ),
                'semi_structured_checkbox_target_accuracy': workflow_input(
                    Settings.SemiStructuredCheckboxTargetAccuracy
                ),
                'semi_structured_checkbox_confidence_threshold': workflow_input(
                    Settings.SemiStructuredCheckboxThreshold
                ),
                'semi_structured_checkbox_acceptable_confidence': workflow_input(
                    Settings.SemiStructuredCheckboxMinLegThreshold
                ),
            },
            title='Machine Transcription',
            description='Automatically transcribe fields',
        )


# Manual transcription lets your keyers manually enter the text found in fields or tables
# that could not be automatically transcribed
class ManualTranscriptionV2Block(Block):
    def __init__(
        self,
        reference_name: str,
        submission: Any,
        api_params: Any,
        supervision_transcription_masking: bool = True,
        table_output_manual_review: bool = False,
        task_restrictions: Optional[List[Any]] = None,
    ) -> None:
        if not task_restrictions:
            task_restrictions = []

        manual_transcription_enabled = workflow_input(Settings.ManualTranscriptionEnabled)
        super().__init__(
            identifier='MANUAL_TRANSCRIPTION_2',
            reference_name=reference_name,
            input={
                'submission': submission,
                'api_params': api_params,
                'task_restrictions': task_restrictions,
                'manual_transcription_enabled': manual_transcription_enabled,
                'supervision_transcription_masking': supervision_transcription_masking,
                'table_output_manual_review': table_output_manual_review,
                'notification_workflow': IDP_SUBMISSION_NOTIFY_NAME,
            },
            title='Manual Transcription',
            description='Manually transcribe fields that could not be automatically transcribed',
        )


# Flexible extraction manually transcribes fields marked for review
class FlexibleExtractionBlock(Block):
    def __init__(
        self,
        reference_name: str,
        submission: Any,
        api_params: Any,
        supervision_transcription_masking: bool = True,
        task_restrictions: Optional[List[Any]] = None,
    ) -> None:
        if not task_restrictions:
            task_restrictions = []

        super().__init__(
            identifier='FLEXIBLE_EXTRACTION',
            reference_name=reference_name,
            input={
                'layout_release_uuid': workflow_input(Settings.LayoutReleaseUuid),
                'api_params': api_params,
                'submission': submission,
                'task_restrictions': task_restrictions,
                'supervision_transcription_masking': supervision_transcription_masking,
                'notification_workflow': IDP_SUBMISSION_NOTIFY_NAME,
            },
            title='Flexible Extraction',
            description='Manually transcribe fields marked for review',
        )


# Submission complete block finalizes submission processing and updates reporting data
class SubmissionCompleteV3Block(Block):
    def __init__(self, reference_name: str, submission: str) -> None:
        super().__init__(
            identifier='SUBMISSION_COMPLETE_3',
            reference_name=reference_name,
            input={
                'submission': submission,
                'nlc_qa_sampling_ratio': workflow_input(Settings.SemiQaSampleRate),
                'field_id_qa_enabled': workflow_input(Settings.FieldIdQaEnabled),
                'field_id_qa_sampling_ratio': workflow_input(Settings.FieldIdQaSampleRate),
                'table_id_qa_enabled': workflow_input(Settings.TableIdQaEnabled),
                'table_id_qa_sampling_ratio': workflow_input(Settings.TableIdQaSampleRate),
                'transcription_qa_enabled': workflow_input(Settings.TranscriptionQaEnabled),
                'transcription_qa_sampling_ratio': workflow_input(
                    Settings.TranscriptionQaSampleRate
                ),
                'table_cell_transcription_qa_enabled': workflow_input(
                    Settings.TableCellTranscriptionQaEnabled
                ),
                'table_cell_transcription_qa_sample_rate': workflow_input(
                    Settings.TableCellTranscriptionQaSampleRate
                ),
            },
            title='Complete',
            description='Finalize submission processing and update reporting data',
        )


# Output block allows users to send data extracted by this idp flow to other systems
# for downstream processing
class IDPOutputBlock(Output):
    def __init__(self, inputs: Dict[str, Any]) -> None:
        super().__init__(
            reference_name='outputs',
            title='Outputs',
            description='Send submission data to external systems',
            role_filter=[IDP_OUTPUT_ROLE],
            input_template={**inputs, 'enabled': True},
            blocks=[],
        )
