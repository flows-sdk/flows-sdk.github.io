from typing import Any
from uuid import UUID

from flows_sdk.blocks import CodeBlock
from flows_sdk.examples.idp_v32.idp_blocks import (
    CaseCollationV2Block,
    FlexibleExtractionBlock,
    IDPOutputsBlock,
    MachineClassificationV2Block,
    MachineIdentificationV3Block,
    MachineTranscriptionV3Block,
    ManualClassificationV2Block,
    ManualIdentificationV3Block,
    ManualTranscriptionV2Block,
    SubmissionBootstrapV2Block,
    SubmissionCompleteV3Block,
)
from flows_sdk.examples.idp_v32.idp_values import (
    IDPManifest,
    IDPTriggers,
    get_idp_wf_config,
    get_idp_wf_inputs,
)
from flows_sdk.flows import Flow
from flows_sdk.package_utils import export_flow


def entry_point_flow() -> Flow:
    return idp_workflow()


def idp_workflow() -> Flow:
    idp_wf_config = get_idp_wf_config()

    # The idp flow basically processes, modifies and propagates the submission object from
    # block to block
    # Each block's processing result is usually included in the submission object

    # Submission bootstrap block initializes the submission object and prepares external images
    # or other submission data if needed
    submission_bootstrap = SubmissionBootstrapV2Block(reference_name='submission_bootstrap')

    # Case collation block groups files, documents and pages (from the submission) into cases
    # In this example, case collation block receives the submission object and the cases
    # information from submission bootstrap block
    case_collation = CaseCollationV2Block(
        reference_name='machine_collation',
        submission=submission_bootstrap.output('result.submission'),
        cases=submission_bootstrap.output('result.api_params.cases'),
    )

    # Machine classification block automatically matches documents to structured, semi-structured
    # or additional layouts
    # In this example, machine classification block receives the submission object from
    # case collation block
    machine_classification = MachineClassificationV2Block(
        reference_name='machine_classification',
        submission=case_collation.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Manual classification block allows keyers to manually match submissions to their layouts.
    # Keyers may perform manual classification if machine classification cannot automatically
    # match a submission to a layout with high confidence
    # In this example, manual classification block receives the submission object from machine
    # classification block
    manual_classification = ManualClassificationV2Block(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Machine identification automatically identify fields and tables in the submission
    # In this example, machine identification block receives the submission object from manual
    # classification
    machine_identification = MachineIdentificationV3Block(
        reference_name='machine_identification',
        submission=manual_classification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Manual identification allows keyers to complete field identification or table identification
    # tasks, where they draw bounding boxes around the contents of certain fields, table columns
    # or table rows. This identification process ensures that the system will be able to
    # transcribe the correct content in the upcoming transcription process
    # In this example, manual identification block receives the submission object from machine
    # identification
    manual_identification = ManualIdentificationV3Block(
        reference_name='manual_identification',
        submission=machine_identification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Machine transcription automatically transcribes the content of your submission
    # In this example, machine identification block receives the submission object from manual
    # identification
    machine_transcription = MachineTranscriptionV3Block(
        reference_name='machine_transcription',
        submission=manual_identification.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Manual transcription lets your keyers manually enter the text found in fields or tables
    # that could not be automatically transcribed
    # In this example, manual transcription block receives the submission object from machine
    # transcription block
    manual_transcription = ManualTranscriptionV2Block(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    # Flexible extraction manually transcribes fields marked for review
    # In this example, flexible extraction block receives the submission object from manual
    # transcription block
    flexible_extraction = FlexibleExtractionBlock(
        reference_name='flexible_extraction',
        submission=manual_transcription.output('submission'),
        api_params=submission_bootstrap.output('result.api_params'),
        # api_params is some submission processing settings obtained from submission bootstrap
        # that users do not have to worry about
    )

    def _load_submission(submission: Any) -> Any:
        import inspect

        submission_id_ref = submission['id']
        proxy = inspect.stack()[1].frame.f_locals['proxy']
        r = proxy.sdm_get(f'api/v5/submissions/{submission_id_ref}?flat=False')
        return r.json()

    load_submission = CodeBlock(
        reference_name='load_submission',
        code=_load_submission,
        code_input={'submission': flexible_extraction.output('submission')},
        title='Load Submission',
        description='Returns Submission in API v5 Format',
    )

    def _redact_pdf(submission: Any) -> Any:
        import inspect
        import cv2
        import tempfile
        import os
        import subprocess

        # pylint: disable=import-error
        from blocks.base_python_block import BlobCreateParams  # type: ignore
        from sdm_image.image_utils.image_read import blob_to_cv2_image  # type: ignore

        # pylint: enable=import-error

        proxy = inspect.stack()[1].frame.f_locals['proxy']
        color = (0, 0, 0)
        thickness = -1

        try:
            for document in submission['documents']:
                images_list = []
                for page in document['pages']:
                    if page['corrected_image_url']:
                        image_url_parts = page['corrected_image_url'].split('/')
                        image_blob = proxy.fetch_blob(image_url_parts[-1]).content
                        cv2_image = blob_to_cv2_image(image_blob)
                        h, w, _ = cv2_image.shape

                        rect_points = []

                        # Process Fields
                        for field in document['document_fields']:
                            start_x = None
                            start_y = None
                            end_x = None
                            end_y = None

                            if field['page_id'] == page['id'] and (field['output_name'] and
                                                                   'REDACT_' in field[
                                                                       'output_name'].upper()):
                                url = field['field_image_url']
                                if url:
                                    params = url.split('?')
                                    params.pop(0)
                                    coords = params[0].split('&')
                                    for i, coord in enumerate(coords):
                                        pair = coord.split('=')
                                        if i == 0:
                                            start_x = float(pair[1])
                                        elif i == 1:
                                            start_y = float(pair[1])
                                        elif i == 2:
                                            end_x = float(pair[1])
                                        elif i == 3:
                                            end_y = float(pair[1])

                                    if start_x and start_y and end_x and end_y:
                                        start_point = (
                                            int(w * start_x),
                                            int(h * start_y),
                                        )
                                        end_point = (
                                            int(w * end_x),
                                            int(h * end_y),
                                        )

                                        rect_points.append((start_point, end_point))

                        for table in document['document_tables']:
                            for row in table['rows']:
                                for cell in row['cells']:
                                    start_x = None
                                    start_y = None
                                    end_x = None
                                    end_y = None

                                    if cell['page_id'] == page['id'] and (
                                            cell['column_name'] and 'REDACT' in cell[
                                        'column_name'].upper()):
                                        start_x = cell['bounding_box'][0]
                                        start_y = cell['bounding_box'][1]
                                        end_x = cell['bounding_box'][2]
                                        end_y = cell['bounding_box'][3]

                                        if start_x and start_y and end_x and end_y:
                                            start_point = (
                                                int(w * start_x),
                                                int(h * start_y),
                                            )
                                            end_point = (
                                                int(w * end_x),
                                                int(h * end_y),
                                            )

                                            rect_points.append((start_point, end_point))

                        for point in rect_points:
                            cv2_image = cv2.rectangle(
                                cv2_image, point[0], point[1], color, thickness
                            )

                        tmp_file = tempfile.NamedTemporaryFile()
                        tmp_file.write(cv2.imencode('.tiff', cv2_image)[1].tobytes())
                        tmp_file.flush()
                        os.fsync(tmp_file.fileno())
                        images_list.append(tmp_file)

                if images_list:
                    images_list.append(tempfile.NamedTemporaryFile())
                    command = ['tiffcp', *[image_file.name for image_file in images_list]]

                    run_result_join = subprocess.run(
                        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                    )
                    if run_result_join.stderr:
                        # submission['exceptions']
                        return submission

                    images_list.append(tempfile.NamedTemporaryFile())
                    command = ['tiff2pdf', '-o', images_list[-1].name, '-F', images_list[-2].name]

                    run_result_pdf = subprocess.run(
                        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE
                    )

                    if run_result_pdf.stderr:
                        # submission['exceptions']
                        return submission

                    with open(images_list[-1].name, 'rb') as f:
                        blob_file = proxy.store_blob(
                            BlobCreateParams(name='document_{}_redacted_pdf'.format(document[
                                                                                        'id']),
                                             content=f.read())
                        )

                    document['redacted_pdf'] = '/api/block_storage/{}/download'.format(
                        blob_file['uuid'])
        finally:
            for image_file in images_list:
                image_file.close()
        return submission

    redact_pdf = CodeBlock(
        reference_name='redact_pdf',
        code=_redact_pdf,
        code_input={'submission': load_submission.output()},
        title='Redact PDF',
        description='Redact a PDF based on field configuration',
    )

    def _mark_as_completed(submission: Any) -> Any:
        from datetime import datetime

        dt_completed = datetime.isoformat(datetime.utcnow())
        dt_completed_fmt = dt_completed + 'Z'

        for document in submission['documents']:
            document['state'] = 'complete'
            document['complete_time'] = dt_completed_fmt

            for page in document['pages']:
                page['state'] = 'complete'

        for page in submission['unassigned_pages']:
            page['state'] = 'complete'

        submission['state'] = 'complete'
        submission['complete_time'] = dt_completed_fmt

        return submission

    # Custom code block enables users to transform and validate extracted submission data
    # before Hyperscience sends it to downstream systems
    # In this example, user created a _mark_as_completed function to transform and validate
    # submission data
    # Notice that the _mark_as_completed function takes in a single argument which is passed
    # in using the code_input parameter
    mark_as_complete = CodeBlock(
        reference_name='mark_as_completed',
        code=_mark_as_completed,
        code_input={'submission': redact_pdf.output()},
        title='Mark As Completed',
        description='Updated Transformed JSON to Completed State',
    )

    # Submission complete block finalizes submission processing and updates reporting data
    # Every flow needs a complete block because it initiates Quality Assurance tasks and
    # changes the submission's status to "Complete"
    # In this example, submission complete block receives the submission object from
    # marked_as_complete custom code block
    submission_complete = SubmissionCompleteV3Block(
        reference_name='complete_submission',
        payload=mark_as_complete.output(),
        submission=mark_as_complete.output()
    )

    # Output block allows users to send data extracted by this idp flow to other systems
    # for downstream processing
    # In this example, this is an empty output block that does not do anything by default
    outputs = IDPOutputsBlock(
        inputs={'submission': submission_bootstrap.output('result.submission')}
    )

    return Flow(
        # Flows should have a deterministic UUID ensuring cross-system consistency
        uuid=UUID('9174f4b5-2809-4a09-a25c-18b870b94945'),
        owner_email='chris.card@hyperscience.com',
        title='PDF Redaction (Field Based)',
        # Flow identifiers are globally unique
        manifest=IDPManifest(flow_identifier='PDF_REDACTION_FIELD_BASED'),
        # It is important to include all blocks that are instantiated here in the blocks
        # field and make sure they follow the order of the flow. For example, if machine
        # classification depends on the output of case collation, then case_collation must
        # come before machine_classification in this blocks array
        blocks=[
            submission_bootstrap,
            case_collation,
            machine_classification,
            manual_classification,
            machine_identification,
            manual_identification,
            machine_transcription,
            manual_transcription,
            flexible_extraction,
            load_submission,
            redact_pdf,
            mark_as_complete,
            submission_complete,
            outputs,
        ],
        input=get_idp_wf_inputs(idp_wf_config),
        description='PDF Redaction based on Field Configuration',
        triggers=IDPTriggers(),
        output={'submission': submission_complete.output()},
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
